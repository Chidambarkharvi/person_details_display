

  export const details = [
    {
      name: "James",
      age: 23,
      img: "https://media.istockphoto.com/photos/smiling-indian-business-man-working-on-laptop-at-home-office-young-picture-id1307615661?b=1&k=20&m=1307615661&s=170667a&w=0&h=Zp9_27RVS_UdlIm2k8sa8PuutX9K3HTs8xdK0UfKmYk=",
    },
    {
      name: "Daniel",
      age: 27,
      img: "https://media.istockphoto.com/photos/good-opportunity-just-made-its-way-to-her-picture-id1284106261?b=1&k=20&m=1284106261&s=170667a&w=0&h=tT99_j-_Q7flxbpQNGPGL6fT6n7h6HokRMTkAZp_DPQ=",
    },
    {
      name: "Robert",
      age: 22,
      img: "https://media.istockphoto.com/photos/put-more-in-get-more-out-picture-id1291318636?b=1&k=20&m=1291318636&s=170667a&w=0&h=UvVIk7wwkN3X9OFm8gBlWWviV5vAjfrq2ejYP30JmnA=",
    },
    {
      name:"Jessey",
      age:33,
      img:"https://media.istockphoto.com/photos/productivity-powered-by-digital-technology-picture-id1330965067?b=1&k=20&m=1330965067&s=170667a&w=0&h=ys_MV3zYkn2HJCtHC4s_03Sz1MUC2BZv6PcDdk__XSc="
    },
    {
      name:"william",
      age:34,
      img:"https://media.istockphoto.com/photos/close-up-thoughtful-man-wearing-glasses-looking-at-laptop-screen-picture-id1309791067?k=20&m=1309791067&s=612x612&w=0&h=k9CesQYtADhToWlgOM4gnOH2wwy96a2kzEP4T7wRigw="
    },
    {
      name:"Richard",
      age:45,
      img:"https://media.istockphoto.com/photos/student-working-on-laptop-at-home-during-covid19-quarantine-picture-id1312458788?k=20&m=1312458788&s=612x612&w=0&h=y9fm3mhd79L2DpG4boqgLn7raXXhRJw0JFUYIgt7Uwk="
    },{
      name:"Michael",
      age:52,
      img:"https://media.istockphoto.com/photos/happy-student-studying-while-using-laptop-picture-id1030344912?k=20&m=1030344912&s=612x612&w=0&h=8WLFXTiDTpUcBQjlVgBVi81mzguUaafCKYpSnzqgXA4="
    },{
      name:"John",
      age:29,
      img:"https://media.istockphoto.com/photos/stylish-guy-working-picture-id881073958?k=20&m=881073958&s=612x612&w=0&h=tHQLWq5_Elta5f0iixylwNrRB2uzVi8YGHVANvTItGE="
    },{
      name:"Charles",
      age:32,
      img:"https://media.istockphoto.com/photos/handsome-caucasian-man-working-on-laptop-computer-while-sitting-on-a-picture-id1313422837?k=20&m=1313422837&s=612x612&w=0&h=MDga4k6DZnazHbnbDvXh65HRYOZXCIn3uYGZ05p5yAY="
    },{
      name:"Mathew",
      age:52,
      img:"https://media.istockphoto.com/photos/young-man-in-a-office-picture-id1282935675?k=20&m=1282935675&s=612x612&w=0&h=4QL2Cs8tEJyQKaN7morTwOrfnwTz3SfUmoiklgRLzFE="
    }
  ]
